window.personas = [
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 19:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 20:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 20:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 21:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 21:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 22:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 13:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 14:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 14:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 18:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 19:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 20:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 20:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 19:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 13:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 13:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-09 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-09 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-09 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-09 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-09 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-09 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-09 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 09:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 09:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 10:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-09 10:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-09 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 11:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 12:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 12:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 13:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 13:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 14:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 14:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 18:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 19:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 19:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO HENRIQUEZ GUTIERREZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-09 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO HENRIQUEZ GUTIERREZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-09 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO HENRIQUEZ GUTIERREZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-09 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO HENRIQUEZ GUTIERREZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-09 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO HENRIQUEZ GUTIERREZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-09 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO HENRIQUEZ GUTIERREZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-09 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO HENRIQUEZ GUTIERREZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-09 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO HENRIQUEZ GUTIERREZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-09 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO HENRIQUEZ GUTIERREZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-09 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO HENRIQUEZ GUTIERREZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-09 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO HENRIQUEZ GUTIERREZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-09 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO HENRIQUEZ GUTIERREZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-09 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO HENRIQUEZ GUTIERREZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-09 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO HENRIQUEZ GUTIERREZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-09 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO HENRIQUEZ GUTIERREZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-09 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO HENRIQUEZ GUTIERREZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-09 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO HENRIQUEZ GUTIERREZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-09 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO HENRIQUEZ GUTIERREZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-09 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO HENRIQUEZ GUTIERREZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-09 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO HENRIQUEZ GUTIERREZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-09 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO HENRIQUEZ GUTIERREZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-09 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO HENRIQUEZ GUTIERREZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-09 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO HENRIQUEZ GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-09 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 19:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-09 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-09 20:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 21:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-09 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-09 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 06:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-09 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-09 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-09 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 19:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 09:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 09:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 11:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 11:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 12:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 12:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 13:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 13:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 14:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 14:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 18:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 06:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-09 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-09 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-09 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 20:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 21:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-09 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-09 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-09 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-09 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-09 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-09 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-09 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-09 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-09 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 06:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-09 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-09 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-09 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-09 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 19:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-09 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-09 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  }
];