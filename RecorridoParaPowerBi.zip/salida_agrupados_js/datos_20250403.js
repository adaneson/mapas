window.personas = [
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-03 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTHIAN ANDRÉS VEGA ROBLEDO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 06:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-03 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-03 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-03 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-03 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-03 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-03 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-03 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 15:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 07:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 08:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-03 08:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 09:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-03 09:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-03 10:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-03 10:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-03 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-03 11:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-03 12:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-03 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-03 13:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-03 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-03 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 14:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 15:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 15:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-03 17:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-03 17:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 18:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 06:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS GUTIERREZ LIMACHE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARTIN ZAPATA ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "MARTIN ZAPATA ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN ZAPATA ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN ZAPATA ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN ZAPATA ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN ZAPATA ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN ZAPATA ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN ZAPATA ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN ZAPATA ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN ZAPATA ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN ZAPATA ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN ZAPATA ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN ZAPATA ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN ZAPATA ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN ZAPATA ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN ZAPATA ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN ZAPATA ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN ZAPATA ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN ZAPATA ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN ZAPATA ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN ZAPATA ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN ZAPATA ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN ZAPATA ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN ZAPATA ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-04-03 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-03 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-04-03 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-03 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-03 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-03 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-03 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-03 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-03 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  }
];