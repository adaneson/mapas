window.personas = [
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 06:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 06:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 11:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 11:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 12:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 12:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 13:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 13:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 14:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 14:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 19:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 19:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 19:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 06:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 19:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RODOLFO ALEJANDRO  AGUILERA  OVALLE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 06:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODOLFO ALEJANDRO  AGUILERA  OVALLE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODOLFO ALEJANDRO  AGUILERA  OVALLE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODOLFO ALEJANDRO  AGUILERA  OVALLE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODOLFO ALEJANDRO  AGUILERA  OVALLE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODOLFO ALEJANDRO  AGUILERA  OVALLE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODOLFO ALEJANDRO  AGUILERA  OVALLE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODOLFO ALEJANDRO  AGUILERA  OVALLE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODOLFO ALEJANDRO  AGUILERA  OVALLE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODOLFO ALEJANDRO  AGUILERA  OVALLE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODOLFO ALEJANDRO  AGUILERA  OVALLE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODOLFO ALEJANDRO  AGUILERA  OVALLE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODOLFO ALEJANDRO  AGUILERA  OVALLE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODOLFO ALEJANDRO  AGUILERA  OVALLE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODOLFO ALEJANDRO  AGUILERA  OVALLE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODOLFO ALEJANDRO  AGUILERA  OVALLE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODOLFO ALEJANDRO  AGUILERA  OVALLE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODOLFO ALEJANDRO  AGUILERA  OVALLE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODOLFO ALEJANDRO  AGUILERA  OVALLE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODOLFO ALEJANDRO  AGUILERA  OVALLE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODOLFO ALEJANDRO  AGUILERA  OVALLE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODOLFO ALEJANDRO  AGUILERA  OVALLE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODOLFO ALEJANDRO  AGUILERA  OVALLE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODOLFO ALEJANDRO  AGUILERA  OVALLE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODOLFO ALEJANDRO  AGUILERA  OVALLE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODOLFO ALEJANDRO  AGUILERA  OVALLE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODOLFO ALEJANDRO  AGUILERA  OVALLE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODOLFO ALEJANDRO  AGUILERA  OVALLE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 20:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 11:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 11:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 12:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 12:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 13:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 13:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 14:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 14:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 15:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 16:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 17:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 19:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 19:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 20:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 06:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 19:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 19:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "ALEXY JESUS ROJAS CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 06:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "ALEXY JESUS ROJAS CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEXY JESUS ROJAS CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEXY JESUS ROJAS CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEXY JESUS ROJAS CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEXY JESUS ROJAS CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEXY JESUS ROJAS CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEXY JESUS ROJAS CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEXY JESUS ROJAS CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEXY JESUS ROJAS CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEXY JESUS ROJAS CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEXY JESUS ROJAS CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEXY JESUS ROJAS CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEXY JESUS ROJAS CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEXY JESUS ROJAS CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEXY JESUS ROJAS CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEXY JESUS ROJAS CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEXY JESUS ROJAS CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEXY JESUS ROJAS CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEXY JESUS ROJAS CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEXY JESUS ROJAS CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEXY JESUS ROJAS CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEXY JESUS ROJAS CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEXY JESUS ROJAS CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEXY JESUS ROJAS CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEXY JESUS ROJAS CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 06:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 07:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 19:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 14:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 14:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 15:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS GUTIERREZ LIMACHE",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 21:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS GUTIERREZ LIMACHE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 21:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "ANDERSON OBREGON  PALOMINO",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SEVERINO  QUISPE MOLINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SEVERINO  QUISPE MOLINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEVERINO  QUISPE MOLINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEVERINO  QUISPE MOLINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEVERINO  QUISPE MOLINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEVERINO  QUISPE MOLINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEVERINO  QUISPE MOLINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEVERINO  QUISPE MOLINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEVERINO  QUISPE MOLINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEVERINO  QUISPE MOLINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEVERINO  QUISPE MOLINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEVERINO  QUISPE MOLINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEVERINO  QUISPE MOLINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEVERINO  QUISPE MOLINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEVERINO  QUISPE MOLINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEVERINO  QUISPE MOLINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEVERINO  QUISPE MOLINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEVERINO  QUISPE MOLINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEVERINO  QUISPE MOLINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEVERINO  QUISPE MOLINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEVERINO  QUISPE MOLINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEVERINO  QUISPE MOLINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEVERINO  QUISPE MOLINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEVERINO  QUISPE MOLINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEVERINO  QUISPE MOLINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEVERINO  QUISPE MOLINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 06:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-19 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 19:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-19 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-19 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-19 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-19 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  }
];