window.personas = [
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ABEL  SANCHEZ ARAVENA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS HUMBERTO CASTRO MALDONADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS HUMBERTO CASTRO MALDONADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS HUMBERTO CASTRO MALDONADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS HUMBERTO CASTRO MALDONADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS HUMBERTO CASTRO MALDONADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS HUMBERTO CASTRO MALDONADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS HUMBERTO CASTRO MALDONADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS HUMBERTO CASTRO MALDONADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS HUMBERTO CASTRO MALDONADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS HUMBERTO CASTRO MALDONADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS HUMBERTO CASTRO MALDONADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS HUMBERTO CASTRO MALDONADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS HUMBERTO CASTRO MALDONADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS HUMBERTO CASTRO MALDONADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS HUMBERTO CASTRO MALDONADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS HUMBERTO CASTRO MALDONADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS HUMBERTO CASTRO MALDONADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS HUMBERTO CASTRO MALDONADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS HUMBERTO CASTRO MALDONADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS HUMBERTO CASTRO MALDONADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS HUMBERTO CASTRO MALDONADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS HUMBERTO CASTRO MALDONADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS HUMBERTO CASTRO MALDONADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS HUMBERTO CASTRO MALDONADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS HUMBERTO CASTRO MALDONADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS HUMBERTO CASTRO MALDONADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JORDÁN ALEX ARANCIBIA PEREIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JORDÁN ALEX ARANCIBIA PEREIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORDÁN ALEX ARANCIBIA PEREIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORDÁN ALEX ARANCIBIA PEREIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORDÁN ALEX ARANCIBIA PEREIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORDÁN ALEX ARANCIBIA PEREIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORDÁN ALEX ARANCIBIA PEREIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORDÁN ALEX ARANCIBIA PEREIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORDÁN ALEX ARANCIBIA PEREIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORDÁN ALEX ARANCIBIA PEREIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORDÁN ALEX ARANCIBIA PEREIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORDÁN ALEX ARANCIBIA PEREIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORDÁN ALEX ARANCIBIA PEREIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORDÁN ALEX ARANCIBIA PEREIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORDÁN ALEX ARANCIBIA PEREIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORDÁN ALEX ARANCIBIA PEREIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORDÁN ALEX ARANCIBIA PEREIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORDÁN ALEX ARANCIBIA PEREIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORDÁN ALEX ARANCIBIA PEREIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORDÁN ALEX ARANCIBIA PEREIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORDÁN ALEX ARANCIBIA PEREIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORDÁN ALEX ARANCIBIA PEREIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORDÁN ALEX ARANCIBIA PEREIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORDÁN ALEX ARANCIBIA PEREIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORDÁN ALEX ARANCIBIA PEREIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE MANUEL GAHONA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE MANUEL GAHONA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL GAHONA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL GAHONA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL GAHONA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL GAHONA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL GAHONA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL GAHONA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL GAHONA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL GAHONA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL GAHONA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL GAHONA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL GAHONA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL GAHONA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL GAHONA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL GAHONA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL GAHONA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL GAHONA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL GAHONA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL GAHONA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL GAHONA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL GAHONA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL GAHONA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL GAHONA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL GAHONA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL GAHONA LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO ARIEL INOSTROZA REBOLLEDO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO ARIEL INOSTROZA REBOLLEDO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ARIEL INOSTROZA REBOLLEDO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ARIEL INOSTROZA REBOLLEDO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 19:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 19:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSÉ GABRIEL GOMEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR HUGO VICENCIO ORREGO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR HUGO VICENCIO ORREGO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR HUGO VICENCIO ORREGO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR HUGO VICENCIO ORREGO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 19:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 20:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 20:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 21:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 19:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO OCTAVIO BELTRAN SEGOVIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO OCTAVIO BELTRAN SEGOVIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO OCTAVIO BELTRAN SEGOVIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO OCTAVIO BELTRAN SEGOVIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO OCTAVIO BELTRAN SEGOVIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO OCTAVIO BELTRAN SEGOVIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO OCTAVIO BELTRAN SEGOVIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO OCTAVIO BELTRAN SEGOVIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO OCTAVIO BELTRAN SEGOVIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO OCTAVIO BELTRAN SEGOVIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO OCTAVIO BELTRAN SEGOVIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO OCTAVIO BELTRAN SEGOVIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO OCTAVIO BELTRAN SEGOVIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO OCTAVIO BELTRAN SEGOVIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO OCTAVIO BELTRAN SEGOVIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO OCTAVIO BELTRAN SEGOVIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO OCTAVIO BELTRAN SEGOVIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO OCTAVIO BELTRAN SEGOVIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO OCTAVIO BELTRAN SEGOVIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO OCTAVIO BELTRAN SEGOVIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO OCTAVIO BELTRAN SEGOVIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO OCTAVIO BELTRAN SEGOVIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO OCTAVIO BELTRAN SEGOVIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO OCTAVIO BELTRAN SEGOVIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO OCTAVIO BELTRAN SEGOVIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO OCTAVIO BELTRAN SEGOVIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMILIANO BARRA HERNANDEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAXIMILIANO BARRA HERNANDEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMILIANO BARRA HERNANDEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMILIANO BARRA HERNANDEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GILBERTO ANGEL YUCLA ANZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GILBERTO ANGEL YUCLA ANZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO ANGEL YUCLA ANZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO ANGEL YUCLA ANZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO ANGEL YUCLA ANZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO ANGEL YUCLA ANZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO ANGEL YUCLA ANZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO ANGEL YUCLA ANZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO ANGEL YUCLA ANZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO ANGEL YUCLA ANZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO ANGEL YUCLA ANZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO ANGEL YUCLA ANZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO ANGEL YUCLA ANZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO ANGEL YUCLA ANZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO ANGEL YUCLA ANZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO ANGEL YUCLA ANZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO ANGEL YUCLA ANZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO ANGEL YUCLA ANZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO ANGEL YUCLA ANZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO ANGEL YUCLA ANZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO ANGEL YUCLA ANZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO ANGEL YUCLA ANZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO ANGEL YUCLA ANZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO ANGEL YUCLA ANZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GILBERTO ANGEL YUCLA ANZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO ANGEL YUCLA ANZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SAMUEL RÍOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 19:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 20:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 20:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 21:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ALONSO YAÑEZ PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ALONSO YAÑEZ PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ALONSO YAÑEZ PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ALONSO YAÑEZ PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ALONSO YAÑEZ PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ALONSO YAÑEZ PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ALONSO YAÑEZ PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ALONSO YAÑEZ PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ALONSO YAÑEZ PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ALONSO YAÑEZ PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ALONSO YAÑEZ PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ALONSO YAÑEZ PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ALONSO YAÑEZ PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ALONSO YAÑEZ PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ALONSO YAÑEZ PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ALONSO YAÑEZ PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ALONSO YAÑEZ PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ALONSO YAÑEZ PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ALONSO YAÑEZ PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ALONSO YAÑEZ PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ALONSO YAÑEZ PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ALONSO YAÑEZ PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ALONSO YAÑEZ PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ALONSO YAÑEZ PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ALONSO YAÑEZ PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ALONSO YAÑEZ PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO  ARAYA  CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO  ARAYA  CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO  ARAYA  CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO  ARAYA  CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO  ARAYA  CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO  ARAYA  CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO  ARAYA  CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO  ARAYA  CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO  ARAYA  CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO  ARAYA  CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO  ARAYA  CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO  ARAYA  CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO  ARAYA  CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO  ARAYA  CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO  ARAYA  CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO  ARAYA  CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO  ARAYA  CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO  ARAYA  CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO  ARAYA  CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO  ARAYA  CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO  ARAYA  CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO  ARAYA  CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO  ARAYA  CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO FELIPE ECHAURREN ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODOLFO ALEJANDRO  AGUILERA  OVALLE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 21:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES PANDO PALMA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES PANDO PALMA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES PANDO PALMA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES PANDO PALMA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES PANDO PALMA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES PANDO PALMA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES PANDO PALMA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES PANDO PALMA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES PANDO PALMA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES PANDO PALMA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES PANDO PALMA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES PANDO PALMA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES PANDO PALMA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES PANDO PALMA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES PANDO PALMA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES PANDO PALMA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES PANDO PALMA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES PANDO PALMA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES PANDO PALMA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES PANDO PALMA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES PANDO PALMA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES PANDO PALMA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES PANDO PALMA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES PANDO PALMA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 08:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 08:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-24 10:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-24 11:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-24 12:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-24 13:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-24 17:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 18:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIZABETH DIAZ SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIZABETH DIAZ SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIZABETH DIAZ SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIZABETH DIAZ SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIO MAURICIO TRUJILLO JERALDO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIO MAURICIO TRUJILLO JERALDO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO MAURICIO TRUJILLO JERALDO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO MAURICIO TRUJILLO JERALDO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO MAURICIO TRUJILLO JERALDO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO MAURICIO TRUJILLO JERALDO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO MAURICIO TRUJILLO JERALDO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO MAURICIO TRUJILLO JERALDO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO MAURICIO TRUJILLO JERALDO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO MAURICIO TRUJILLO JERALDO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO MAURICIO TRUJILLO JERALDO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO MAURICIO TRUJILLO JERALDO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO MAURICIO TRUJILLO JERALDO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO MAURICIO TRUJILLO JERALDO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO MAURICIO TRUJILLO JERALDO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO MAURICIO TRUJILLO JERALDO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO MAURICIO TRUJILLO JERALDO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO MAURICIO TRUJILLO JERALDO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO MAURICIO TRUJILLO JERALDO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO MAURICIO TRUJILLO JERALDO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO MAURICIO TRUJILLO JERALDO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO MAURICIO TRUJILLO JERALDO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO MAURICIO TRUJILLO JERALDO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN FELIPE ABURTO ABURTO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN FELIPE ABURTO ABURTO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE ABURTO ABURTO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE ABURTO ABURTO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE ABURTO ABURTO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE ABURTO ABURTO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE ABURTO ABURTO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE ABURTO ABURTO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE ABURTO ABURTO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE ABURTO ABURTO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE ABURTO ABURTO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE ABURTO ABURTO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE ABURTO ABURTO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE ABURTO ABURTO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE ABURTO ABURTO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE ABURTO ABURTO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE ABURTO ABURTO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE ABURTO ABURTO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE ABURTO ABURTO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE ABURTO ABURTO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE ABURTO ABURTO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE ABURTO ABURTO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE ABURTO ABURTO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE ABURTO ABURTO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE ABURTO ABURTO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE ABURTO ABURTO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 19:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "EDUARD CASTELLANO CEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARD CASTELLANO CEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDUARD CASTELLANO CEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDUARD CASTELLANO CEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDUARD CASTELLANO CEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDUARD CASTELLANO CEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDUARD CASTELLANO CEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDUARD CASTELLANO CEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDUARD CASTELLANO CEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDUARD CASTELLANO CEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARD CASTELLANO CEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDUARD CASTELLANO CEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDUARD CASTELLANO CEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDUARD CASTELLANO CEPEDA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDUARD CASTELLANO CEPEDA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARD CASTELLANO CEPEDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDUARD CASTELLANO CEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDUARD CASTELLANO CEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDUARD CASTELLANO CEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDUARD CASTELLANO CEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARD CASTELLANO CEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDUARD CASTELLANO CEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARD CASTELLANO CEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARD CASTELLANO CEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO ALFREDO GERALDO ALVEAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO ALFREDO GERALDO ALVEAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO ALFREDO GERALDO ALVEAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO ALFREDO GERALDO ALVEAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALFREDO GERALDO ALVEAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO ALFREDO GERALDO ALVEAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALFREDO GERALDO ALVEAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALFREDO GERALDO ALVEAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALFREDO GERALDO ALVEAR",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALFREDO GERALDO ALVEAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALFREDO GERALDO ALVEAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALFREDO GERALDO ALVEAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALFREDO GERALDO ALVEAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALFREDO GERALDO ALVEAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALFREDO GERALDO ALVEAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALFREDO GERALDO ALVEAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALFREDO GERALDO ALVEAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALFREDO GERALDO ALVEAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO ALFREDO GERALDO ALVEAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KATHERINNE  AVILA LAGOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 14:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 15:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 15:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 16:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 16:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 17:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 17:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 18:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AXL ROBERT MORGADO NEIRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YON JAIRO ANGULO VALENCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 19:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-24 11:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-24 12:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-24 12:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-24 13:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-24 13:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 15:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-24 15:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 16:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-24 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS GUTIERREZ LIMACHE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS GUTIERREZ LIMACHE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS GUTIERREZ LIMACHE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS GUTIERREZ LIMACHE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS GUTIERREZ LIMACHE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS GUTIERREZ LIMACHE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS GUTIERREZ LIMACHE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS GUTIERREZ LIMACHE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS GUTIERREZ LIMACHE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS GUTIERREZ LIMACHE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS GUTIERREZ LIMACHE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS GUTIERREZ LIMACHE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS GUTIERREZ LIMACHE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS GUTIERREZ LIMACHE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS GUTIERREZ LIMACHE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS GUTIERREZ LIMACHE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS GUTIERREZ LIMACHE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS GUTIERREZ LIMACHE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS GUTIERREZ LIMACHE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS GUTIERREZ LIMACHE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS GUTIERREZ LIMACHE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS GUTIERREZ LIMACHE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS GUTIERREZ LIMACHE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER  SAUCEDO MERCADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO FELIX AYZA GUTIERREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANDERSON OBREGON  PALOMINO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARMELO  MENDEZ TERRAZAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARMELO  MENDEZ TERRAZAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARMELO  MENDEZ TERRAZAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARMELO  MENDEZ TERRAZAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARMELO  MENDEZ TERRAZAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARMELO  MENDEZ TERRAZAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARMELO  MENDEZ TERRAZAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARMELO  MENDEZ TERRAZAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARMELO  MENDEZ TERRAZAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARMELO  MENDEZ TERRAZAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARMELO  MENDEZ TERRAZAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARMELO  MENDEZ TERRAZAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARMELO  MENDEZ TERRAZAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARMELO  MENDEZ TERRAZAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARMELO  MENDEZ TERRAZAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARMELO  MENDEZ TERRAZAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARMELO  MENDEZ TERRAZAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARMELO  MENDEZ TERRAZAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARMELO  MENDEZ TERRAZAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARMELO  MENDEZ TERRAZAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARMELO  MENDEZ TERRAZAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARMELO  MENDEZ TERRAZAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARMELO  MENDEZ TERRAZAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARMELO  MENDEZ TERRAZAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARMELO  MENDEZ TERRAZAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JESUS JOSE LIRA SILVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JESUS JOSE LIRA SILVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JESUS JOSE LIRA SILVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JESUS JOSE LIRA SILVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BEIMAR SEBASTIÁN CALLE OLIVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "BEIMAR SEBASTIÁN CALLE OLIVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BEIMAR SEBASTIÁN CALLE OLIVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BEIMAR SEBASTIÁN CALLE OLIVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BEIMAR SEBASTIÁN CALLE OLIVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BEIMAR SEBASTIÁN CALLE OLIVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BEIMAR SEBASTIÁN CALLE OLIVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BEIMAR SEBASTIÁN CALLE OLIVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BEIMAR SEBASTIÁN CALLE OLIVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BEIMAR SEBASTIÁN CALLE OLIVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BEIMAR SEBASTIÁN CALLE OLIVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BEIMAR SEBASTIÁN CALLE OLIVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BEIMAR SEBASTIÁN CALLE OLIVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BEIMAR SEBASTIÁN CALLE OLIVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BEIMAR SEBASTIÁN CALLE OLIVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BEIMAR SEBASTIÁN CALLE OLIVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BEIMAR SEBASTIÁN CALLE OLIVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BEIMAR SEBASTIÁN CALLE OLIVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BEIMAR SEBASTIÁN CALLE OLIVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BEIMAR SEBASTIÁN CALLE OLIVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BEIMAR SEBASTIÁN CALLE OLIVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BEIMAR SEBASTIÁN CALLE OLIVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BEIMAR SEBASTIÁN CALLE OLIVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BEIMAR SEBASTIÁN CALLE OLIVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BEIMAR SEBASTIÁN CALLE OLIVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BEIMAR SEBASTIÁN CALLE OLIVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE LUIS SOTO CASTRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE LUIS SOTO CASTRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LUIS SOTO CASTRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LUIS SOTO CASTRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 08:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 09:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 09:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 10:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 10:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 11:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-24 11:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-24 12:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 12:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 14:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 14:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 15:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-24 15:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 16:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 16:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-24 17:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-24 17:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  }
];