window.personas = [
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-04 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-04 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-04 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-04 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-04 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-04 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-04 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-04 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-04 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-04 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-04 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-04 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-04 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-04 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-04 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-04 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-04 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-04 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-04 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-04 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-04 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-04 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-04 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-04 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-04 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-04 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-04 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO MATIAS MORALES GONZALEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO MATIAS MORALES GONZALEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO MATIAS MORALES GONZALEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO MATIAS MORALES GONZALEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO MATIAS MORALES GONZALEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO MATIAS MORALES GONZALEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO MATIAS MORALES GONZALEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO MATIAS MORALES GONZALEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO MATIAS MORALES GONZALEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO MATIAS MORALES GONZALEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO MATIAS MORALES GONZALEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO MATIAS MORALES GONZALEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO MATIAS MORALES GONZALEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO MATIAS MORALES GONZALEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO MATIAS MORALES GONZALEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO MATIAS MORALES GONZALEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO MATIAS MORALES GONZALEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO MATIAS MORALES GONZALEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO MATIAS MORALES GONZALEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO MATIAS MORALES GONZALEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO MATIAS MORALES GONZALEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO MATIAS MORALES GONZALEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO MATIAS MORALES GONZALEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO MATIAS MORALES GONZALEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-04 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-04 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-04 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-04 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-04 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-04 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-04 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-04 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-04 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-04 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-04 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 07:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 19:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 19:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-04 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-04 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ANDERSON OBREGON  PALOMINO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-04 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  }
];