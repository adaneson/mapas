window.personas = [
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO CORTES ORELLANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALFREDO GERALDO ALVEAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALFREDO GERALDO ALVEAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-25 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALFREDO GERALDO ALVEAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-25 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO ALFREDO GERALDO ALVEAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-25 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALFREDO GERALDO ALVEAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-25 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALFREDO GERALDO ALVEAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-25 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALFREDO GERALDO ALVEAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-25 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO ALFREDO GERALDO ALVEAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-25 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO ALFREDO GERALDO ALVEAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-25 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALFREDO GERALDO ALVEAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-25 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-25 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-25 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-25 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-25 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-25 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-25 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANDERSON OBREGON  PALOMINO",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-25 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-25 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-25 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-25 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  }
];