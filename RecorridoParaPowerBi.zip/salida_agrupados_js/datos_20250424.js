window.personas = [
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 19:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 20:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 20:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL VILLALON LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ANGEL VILLALON LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL VILLALON LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL VILLALON LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL VILLALON LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL VILLALON LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL VILLALON LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL VILLALON LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL VILLALON LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL VILLALON LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL VILLALON LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL VILLALON LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL VILLALON LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL VILLALON LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL VILLALON LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL VILLALON LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL VILLALON LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL VILLALON LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 07:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 18:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO ANTONIO CHINGA ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO ANTONIO CHINGA ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO CHINGA ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO CHINGA ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO CHINGA ROJAS",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO ANTONIO CHINGA ROJAS",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO CHINGA ROJAS",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO CHINGA ROJAS",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO CHINGA ROJAS",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO CHINGA ROJAS",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO CHINGA ROJAS",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO CHINGA ROJAS",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO CHINGA ROJAS",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO CHINGA ROJAS",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO CHINGA ROJAS",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO ANTONIO CHINGA ROJAS",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO CHINGA ROJAS",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO CHINGA ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 06:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 07:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 06:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 07:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 07:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO HERNAN VERGARA GUAIQUILLANCA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO HERNAN VERGARA GUAIQUILLANCA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO HERNAN VERGARA GUAIQUILLANCA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO HERNAN VERGARA GUAIQUILLANCA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO HERNAN VERGARA GUAIQUILLANCA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO HERNAN VERGARA GUAIQUILLANCA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO HERNAN VERGARA GUAIQUILLANCA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO HERNAN VERGARA GUAIQUILLANCA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO HERNAN VERGARA GUAIQUILLANCA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO HERNAN VERGARA GUAIQUILLANCA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO HERNAN VERGARA GUAIQUILLANCA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO HERNAN VERGARA GUAIQUILLANCA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO HERNAN VERGARA GUAIQUILLANCA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 19:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 19:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 20:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 20:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 21:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERT LUIS QUEVEDO ORDENES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERT LUIS QUEVEDO ORDENES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERT LUIS QUEVEDO ORDENES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERT LUIS QUEVEDO ORDENES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERT LUIS QUEVEDO ORDENES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERT LUIS QUEVEDO ORDENES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERT LUIS QUEVEDO ORDENES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERT LUIS QUEVEDO ORDENES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERT LUIS QUEVEDO ORDENES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERT LUIS QUEVEDO ORDENES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERT LUIS QUEVEDO ORDENES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERT LUIS QUEVEDO ORDENES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERT LUIS QUEVEDO ORDENES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERT LUIS QUEVEDO ORDENES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERT LUIS QUEVEDO ORDENES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERT LUIS QUEVEDO ORDENES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERT LUIS QUEVEDO ORDENES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERT LUIS QUEVEDO ORDENES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MOISES ABELARDO GAETE ORTEGA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MOISES ABELARDO GAETE ORTEGA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MOISES ABELARDO GAETE ORTEGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 19:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 20:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 20:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIELLA FERNANDA CABRERA MALDONADO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "DANIELLA FERNANDA CABRERA MALDONADO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIELLA FERNANDA CABRERA MALDONADO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIELLA FERNANDA CABRERA MALDONADO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIELLA FERNANDA CABRERA MALDONADO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIELLA FERNANDA CABRERA MALDONADO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIELLA FERNANDA CABRERA MALDONADO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIELLA FERNANDA CABRERA MALDONADO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIELLA FERNANDA CABRERA MALDONADO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIELLA FERNANDA CABRERA MALDONADO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIELLA FERNANDA CABRERA MALDONADO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIELLA FERNANDA CABRERA MALDONADO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIELLA FERNANDA CABRERA MALDONADO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIELLA FERNANDA CABRERA MALDONADO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIELLA FERNANDA CABRERA MALDONADO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIELLA FERNANDA CABRERA MALDONADO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIELLA FERNANDA CABRERA MALDONADO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIELLA FERNANDA CABRERA MALDONADO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 19:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN PATRICIO PEREZ VICENCIO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JONATHAN PATRICIO PEREZ VICENCIO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN PATRICIO PEREZ VICENCIO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN PATRICIO PEREZ VICENCIO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN PATRICIO PEREZ VICENCIO",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JONATHAN PATRICIO PEREZ VICENCIO",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JONATHAN PATRICIO PEREZ VICENCIO",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JONATHAN PATRICIO PEREZ VICENCIO",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JONATHAN PATRICIO PEREZ VICENCIO",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JONATHAN PATRICIO PEREZ VICENCIO",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JONATHAN PATRICIO PEREZ VICENCIO",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JONATHAN PATRICIO PEREZ VICENCIO",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JONATHAN PATRICIO PEREZ VICENCIO",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JONATHAN PATRICIO PEREZ VICENCIO",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JONATHAN PATRICIO PEREZ VICENCIO",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JONATHAN PATRICIO PEREZ VICENCIO",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN PATRICIO PEREZ VICENCIO",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN PATRICIO PEREZ VICENCIO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 07:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTHIAN ANDRÉS VEGA ROBLEDO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTHIAN ANDRÉS VEGA ROBLEDO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTHIAN ANDRÉS VEGA ROBLEDO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTHIAN ANDRÉS VEGA ROBLEDO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTHIAN ANDRÉS VEGA ROBLEDO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTHIAN ANDRÉS VEGA ROBLEDO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTHIAN ANDRÉS VEGA ROBLEDO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTHIAN ANDRÉS VEGA ROBLEDO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTHIAN ANDRÉS VEGA ROBLEDO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTHIAN ANDRÉS VEGA ROBLEDO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTHIAN ANDRÉS VEGA ROBLEDO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTHIAN ANDRÉS VEGA ROBLEDO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTHIAN ANDRÉS VEGA ROBLEDO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTHIAN ANDRÉS VEGA ROBLEDO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTHIAN ANDRÉS VEGA ROBLEDO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTHIAN ANDRÉS VEGA ROBLEDO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTHIAN ANDRÉS VEGA ROBLEDO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 19:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 20:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 20:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 19:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 20:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 20:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 21:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 19:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 19:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 20:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 20:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.312849261481,
    lng: -68.888485284643,
    tiempo: "2025-04-24 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.312849261481,
    lng: -68.888485284643,
    tiempo: "2025-04-24 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.312849261481,
    lng: -68.888485284643,
    tiempo: "2025-04-24 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.312849261481,
    lng: -68.888485284643,
    tiempo: "2025-04-24 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.312849261481,
    lng: -68.888485284643,
    tiempo: "2025-04-24 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.312849261481,
    lng: -68.888485284643,
    tiempo: "2025-04-24 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JONATAN GONZALEZ SALDIVAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JONATAN GONZALEZ SALDIVAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATAN GONZALEZ SALDIVAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATAN GONZALEZ SALDIVAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATAN GONZALEZ SALDIVAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATAN GONZALEZ SALDIVAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATAN GONZALEZ SALDIVAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATAN GONZALEZ SALDIVAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATAN GONZALEZ SALDIVAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATAN GONZALEZ SALDIVAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATAN GONZALEZ SALDIVAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATAN GONZALEZ SALDIVAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATAN GONZALEZ SALDIVAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATAN GONZALEZ SALDIVAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATAN GONZALEZ SALDIVAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATAN GONZALEZ SALDIVAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATAN GONZALEZ SALDIVAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATAN GONZALEZ SALDIVAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATAN GONZALEZ SALDIVAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATAN GONZALEZ SALDIVAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATAN GONZALEZ SALDIVAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATAN GONZALEZ SALDIVAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATAN GONZALEZ SALDIVAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATAN GONZALEZ SALDIVAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATAN GONZALEZ SALDIVAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATAN GONZALEZ SALDIVAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 19:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 20:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILA ALESSANDRA GALLEANI LOPEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 19:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 07:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 19:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 20:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 20:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.315680530637,
    lng: -68.886395313022,
    tiempo: "2025-04-24 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELMER DANIEL PADILLA TEJERINA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ELMER DANIEL PADILLA TEJERINA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELMER DANIEL PADILLA TEJERINA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELMER DANIEL PADILLA TEJERINA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELMER DANIEL PADILLA TEJERINA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELMER DANIEL PADILLA TEJERINA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.315680530637,
    lng: -68.886395313022,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.315680530637,
    lng: -68.886395313022,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.315680530637,
    lng: -68.886395313022,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.315680530637,
    lng: -68.886395313022,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.315680530637,
    lng: -68.886395313022,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.315680530637,
    lng: -68.886395313022,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.315680530637,
    lng: -68.886395313022,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.315680530637,
    lng: -68.886395313022,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.315680530637,
    lng: -68.886395313022,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALAN DANIEL PINZA CEVALLOS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALAN DANIEL PINZA CEVALLOS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALAN DANIEL PINZA CEVALLOS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALAN DANIEL PINZA CEVALLOS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALAN DANIEL PINZA CEVALLOS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALAN DANIEL PINZA CEVALLOS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALAN DANIEL PINZA CEVALLOS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALAN DANIEL PINZA CEVALLOS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALAN DANIEL PINZA CEVALLOS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALAN DANIEL PINZA CEVALLOS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALAN DANIEL PINZA CEVALLOS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALAN DANIEL PINZA CEVALLOS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALAN DANIEL PINZA CEVALLOS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALAN DANIEL PINZA CEVALLOS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALAN DANIEL PINZA CEVALLOS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALAN DANIEL PINZA CEVALLOS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALAN DANIEL PINZA CEVALLOS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALAN DANIEL PINZA CEVALLOS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO  BLANCO SALAZAR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD DURAN VERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD DURAN VERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD DURAN VERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD DURAN VERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD DURAN VERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD DURAN VERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD DURAN VERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD DURAN VERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD DURAN VERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD DURAN VERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD DURAN VERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD DURAN VERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD DURAN VERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD DURAN VERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD DURAN VERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD DURAN VERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD DURAN VERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD DURAN VERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD DURAN VERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD DURAN VERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD DURAN VERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD DURAN VERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD DURAN VERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD DURAN VERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD DURAN VERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 06:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-04-24 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 06:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.314613635777,
    lng: -68.888110113235,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-04-24 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 07:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-04-24 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-04-24 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-04-24 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-04-24 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 08:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 09:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-24 10:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-24 10:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-24 11:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-24 11:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-24 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-24 12:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-04-24 13:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 13:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 14:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 15:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-04-24 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-04-24 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  }
];