window.personas = [
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOUZA DEL CANTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 07:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 08:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 08:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 12:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 12:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER MONTIEL FIBLAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE RIVERA  ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR MANUEL SANTOS FLORES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 13:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 14:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 17:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO SANTANDER CANESSA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 07:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ENRIQUE RUBILAR RUBILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ENRIQUE RUBILAR RUBILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ENRIQUE RUBILAR RUBILAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ENRIQUE RUBILAR RUBILAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ENRIQUE RUBILAR RUBILAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ENRIQUE RUBILAR RUBILAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ENRIQUE RUBILAR RUBILAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ENRIQUE RUBILAR RUBILAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ENRIQUE RUBILAR RUBILAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ENRIQUE RUBILAR RUBILAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ENRIQUE RUBILAR RUBILAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ENRIQUE RUBILAR RUBILAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ENRIQUE RUBILAR RUBILAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ENRIQUE RUBILAR RUBILAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ENRIQUE RUBILAR RUBILAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ENRIQUE RUBILAR RUBILAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ENRIQUE RUBILAR RUBILAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ENRIQUE RUBILAR RUBILAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ENRIQUE RUBILAR RUBILAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ENRIQUE RUBILAR RUBILAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ENRIQUE RUBILAR RUBILAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ENRIQUE RUBILAR RUBILAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ENRIQUE RUBILAR RUBILAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ENRIQUE RUBILAR RUBILAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ENRIQUE RUBILAR RUBILAR",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 19:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 20:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 19:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 19:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 19:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 12:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 13:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO  ARAYA  ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALEJANDRO DELGADILLO GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAROM PEREZ GONZALEZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAROM PEREZ GONZALEZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAROM PEREZ GONZALEZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAROM PEREZ GONZALEZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAROM PEREZ GONZALEZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAROM PEREZ GONZALEZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAROM PEREZ GONZALEZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAROM PEREZ GONZALEZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAROM PEREZ GONZALEZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAROM PEREZ GONZALEZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAROM PEREZ GONZALEZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAROM PEREZ GONZALEZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAROM PEREZ GONZALEZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAROM PEREZ GONZALEZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAROM PEREZ GONZALEZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAROM PEREZ GONZALEZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAROM PEREZ GONZALEZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAROM PEREZ GONZALEZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAROM PEREZ GONZALEZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAROM PEREZ GONZALEZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAROM PEREZ GONZALEZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAROM PEREZ GONZALEZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAROM PEREZ GONZALEZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAROM PEREZ GONZALEZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAROM PEREZ GONZALEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 19:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE MANUEL AVALOS ORTIZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 07:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 08:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-11 09:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 09:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 10:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 10:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 11:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 11:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 12:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 13:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 13:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 14:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 14:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 15:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 15:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 16:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 16:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-11 17:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 17:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ORDENES PEDRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN RODRIGO VERA GOMEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN RODRIGO VERA GOMEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN RODRIGO VERA GOMEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN RODRIGO VERA GOMEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN RODRIGO VERA GOMEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN RODRIGO VERA GOMEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN RODRIGO VERA GOMEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN RODRIGO VERA GOMEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN RODRIGO VERA GOMEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN RODRIGO VERA GOMEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN RODRIGO VERA GOMEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN RODRIGO VERA GOMEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN RODRIGO VERA GOMEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN RODRIGO VERA GOMEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN RODRIGO VERA GOMEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN RODRIGO VERA GOMEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN RODRIGO VERA GOMEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN RODRIGO VERA GOMEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN RODRIGO VERA GOMEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN RODRIGO VERA GOMEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN RODRIGO VERA GOMEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN RODRIGO VERA GOMEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN RODRIGO VERA GOMEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN RODRIGO VERA GOMEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN RODRIGO VERA GOMEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN RODRIGO VERA GOMEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HABACUT LEMUS ROBLES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HABACUT LEMUS ROBLES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HABACUT LEMUS ROBLES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HABACUT LEMUS ROBLES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HABACUT LEMUS ROBLES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HABACUT LEMUS ROBLES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HABACUT LEMUS ROBLES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HABACUT LEMUS ROBLES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HABACUT LEMUS ROBLES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HABACUT LEMUS ROBLES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HABACUT LEMUS ROBLES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HABACUT LEMUS ROBLES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HABACUT LEMUS ROBLES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HABACUT LEMUS ROBLES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HABACUT LEMUS ROBLES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HABACUT LEMUS ROBLES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HABACUT LEMUS ROBLES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HABACUT LEMUS ROBLES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HABACUT LEMUS ROBLES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HABACUT LEMUS ROBLES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HABACUT LEMUS ROBLES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HABACUT LEMUS ROBLES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HABACUT LEMUS ROBLES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HABACUT LEMUS ROBLES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HABACUT LEMUS ROBLES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 19:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 20:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS ANDRES HERNANDEZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 14:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 14:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 15:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GUERRERO LEIVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWARD ROZAS ALFARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MAMANI ESPINAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 19:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ANDERSON OBREGON  PALOMINO",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-11 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-11 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-11 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUDDY RODRIGO PAJARITO TICONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ZAPATA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ZAPATA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ZAPATA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ZAPATA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ZAPATA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ZAPATA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ZAPATA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ZAPATA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ZAPATA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ZAPATA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ZAPATA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ZAPATA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ZAPATA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ZAPATA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ZAPATA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ZAPATA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ZAPATA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ZAPATA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ZAPATA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ZAPATA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ZAPATA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ZAPATA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ZAPATA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO  CARDENAS  POSSO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 19:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-11 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-11 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 09:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 09:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 10:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 11:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 11:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 12:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 12:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 13:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 13:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 14:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-11 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 17:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO LEIVA ROBLES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-11 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO ARAYA DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSVALDO MUÑOZ ROJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-11 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  }
];