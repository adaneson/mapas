window.personas = [
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: nan,
    lng: nan,
    tiempo: "2025-02-28 22:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-02-28 23:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  }
];