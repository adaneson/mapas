window.personas = [
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 19:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ALEJANDRO CAMPUZANO DIAZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ALEJANDRO CAMPUZANO DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ALEJANDRO CAMPUZANO DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ALEJANDRO CAMPUZANO DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ALEJANDRO CAMPUZANO DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ALEJANDRO CAMPUZANO DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ALEJANDRO CAMPUZANO DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ALEJANDRO CAMPUZANO DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ALEJANDRO CAMPUZANO DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ALEJANDRO CAMPUZANO DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ALEJANDRO CAMPUZANO DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ALEJANDRO CAMPUZANO DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ALEJANDRO CAMPUZANO DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ALEJANDRO CAMPUZANO DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ALEJANDRO CAMPUZANO DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ALEJANDRO CAMPUZANO DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ALEJANDRO CAMPUZANO DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ALEJANDRO CAMPUZANO DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ALEJANDRO CAMPUZANO DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ALEJANDRO CAMPUZANO DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ALEJANDRO CAMPUZANO DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ALEJANDRO CAMPUZANO DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ALEJANDRO CAMPUZANO DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ALEJANDRO CAMPUZANO DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ALEJANDRO CAMPUZANO DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO JIMENEZ PARADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GENESIS GUZMÁN BURBOA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 19:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 19:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANYELO MARCELO BRAVO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANYELO MARCELO BRAVO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANYELO MARCELO BRAVO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANYELO MARCELO BRAVO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANYELO MARCELO BRAVO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANYELO MARCELO BRAVO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANYELO MARCELO BRAVO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANYELO MARCELO BRAVO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANYELO MARCELO BRAVO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANYELO MARCELO BRAVO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANYELO MARCELO BRAVO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANYELO MARCELO BRAVO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANYELO MARCELO BRAVO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANYELO MARCELO BRAVO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANYELO MARCELO BRAVO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANYELO MARCELO BRAVO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANYELO MARCELO BRAVO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANYELO MARCELO BRAVO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANYELO MARCELO BRAVO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANYELO MARCELO BRAVO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANYELO MARCELO BRAVO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANYELO MARCELO BRAVO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANYELO MARCELO BRAVO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANYELO MARCELO BRAVO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANYELO MARCELO BRAVO PIZARRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEXY JESUS ROJAS CONTRERAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEXY JESUS ROJAS CONTRERAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEXY JESUS ROJAS CONTRERAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEXY JESUS ROJAS CONTRERAS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEXY JESUS ROJAS CONTRERAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE IGNACIO ALBA GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 19:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HURTADO VIQUIÑA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO HURTADO VIQUIÑA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO HURTADO VIQUIÑA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HURTADO VIQUIÑA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HURTADO VIQUIÑA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HURTADO VIQUIÑA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO HURTADO VIQUIÑA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO HURTADO VIQUIÑA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO HURTADO VIQUIÑA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO HURTADO VIQUIÑA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO HURTADO VIQUIÑA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO HURTADO VIQUIÑA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO HURTADO VIQUIÑA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO HURTADO VIQUIÑA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO HURTADO VIQUIÑA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO HURTADO VIQUIÑA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HURTADO VIQUIÑA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HURTADO VIQUIÑA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HURTADO VIQUIÑA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO HURTADO VIQUIÑA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO HURTADO VIQUIÑA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO HURTADO VIQUIÑA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO HURTADO VIQUIÑA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO HURTADO VIQUIÑA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO HURTADO VIQUIÑA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRAULIO SOTIZ -",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANDRES MOLINA .",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ANDRES MOLINA .",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANDRES MOLINA .",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANDRES MOLINA .",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANDRES MOLINA .",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANDRES MOLINA .",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANDRES MOLINA .",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANDRES MOLINA .",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANDRES MOLINA .",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANDRES MOLINA .",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANDRES MOLINA .",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANDRES MOLINA .",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANDRES MOLINA .",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANDRES MOLINA .",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANDRES MOLINA .",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANDRES MOLINA .",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANDRES MOLINA .",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANDRES MOLINA .",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANDRES MOLINA .",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANDRES MOLINA .",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANDRES MOLINA .",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANDRES MOLINA .",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANDRES MOLINA .",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANDRES MOLINA .",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANDRES MOLINA .",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDERSON OBREGON  PALOMINO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ROJAS HUARIPAUCAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARMELO AMAPORIVA GARCIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARMELO AMAPORIVA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARMELO AMAPORIVA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARMELO AMAPORIVA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARMELO AMAPORIVA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARMELO AMAPORIVA GARCIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARMELO AMAPORIVA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARMELO AMAPORIVA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARMELO AMAPORIVA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARMELO AMAPORIVA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARMELO AMAPORIVA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARMELO AMAPORIVA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARMELO AMAPORIVA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARMELO AMAPORIVA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARMELO AMAPORIVA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARMELO AMAPORIVA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARMELO AMAPORIVA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARMELO AMAPORIVA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARMELO AMAPORIVA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARMELO AMAPORIVA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARMELO AMAPORIVA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARMELO AMAPORIVA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARMELO AMAPORIVA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARMELO AMAPORIVA GARCIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARMELO AMAPORIVA GARCIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN CHOQUETICLLA CALIZAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN CHOQUETICLLA CALIZAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN CHOQUETICLLA CALIZAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN CHOQUETICLLA CALIZAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN CHOQUETICLLA CALIZAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN CHOQUETICLLA CALIZAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN CHOQUETICLLA CALIZAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN CHOQUETICLLA CALIZAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN CHOQUETICLLA CALIZAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN CHOQUETICLLA CALIZAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN CHOQUETICLLA CALIZAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN CHOQUETICLLA CALIZAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN CHOQUETICLLA CALIZAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN CHOQUETICLLA CALIZAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN CHOQUETICLLA CALIZAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN CHOQUETICLLA CALIZAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN CHOQUETICLLA CALIZAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN CHOQUETICLLA CALIZAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN CHOQUETICLLA CALIZAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN CHOQUETICLLA CALIZAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN CHOQUETICLLA CALIZAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN CHOQUETICLLA CALIZAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN CHOQUETICLLA CALIZAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 06:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-14 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 06:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-14 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-14 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-14 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  }
];