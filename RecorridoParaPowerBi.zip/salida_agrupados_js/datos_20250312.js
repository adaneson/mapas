window.personas = [
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-12 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 19:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 20:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-12 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-12 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-12 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-12 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-12 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-12 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-12 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-12 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-12 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-12 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-12 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-12 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-12 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-12 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-12 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-12 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 19:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 19:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-12 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-12 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-12 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-12 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERIBERTO ANTONIO MORAGA BRITO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-12 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 19:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-12 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-12 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-12 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-12 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-12 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-12 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 19:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 19:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-12 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-12 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-12 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-12 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-12 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-12 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-12 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-12 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-12 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-12 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-12 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID GOMEZ FERRER",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-12 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-12 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-12 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-12 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 07:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 19:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-12 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-12 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-12 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 19:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ANDERSON OBREGON  PALOMINO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ANDERSON OBREGON  PALOMINO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDERSON OBREGON  PALOMINO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDERSON OBREGON  PALOMINO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDERSON OBREGON  PALOMINO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDERSON OBREGON  PALOMINO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDERSON OBREGON  PALOMINO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDERSON OBREGON  PALOMINO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDERSON OBREGON  PALOMINO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDERSON OBREGON  PALOMINO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDERSON OBREGON  PALOMINO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDERSON OBREGON  PALOMINO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDERSON OBREGON  PALOMINO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDERSON OBREGON  PALOMINO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDERSON OBREGON  PALOMINO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDERSON OBREGON  PALOMINO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDERSON OBREGON  PALOMINO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDERSON OBREGON  PALOMINO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDERSON OBREGON  PALOMINO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDERSON OBREGON  PALOMINO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDERSON OBREGON  PALOMINO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDERSON OBREGON  PALOMINO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDERSON OBREGON  PALOMINO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDERSON OBREGON  PALOMINO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-12 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDERSON OBREGON  PALOMINO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ANDERSON OBREGON  PALOMINO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-12 19:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  }
];