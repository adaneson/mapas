window.personas = [
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANDRÉS OSVALDO MALDONADO PANIRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 06:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 19:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO HECTOR ULLOA VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 20:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL MARCOS LEDEZMA GALLEGUILLOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO  GUAJARDO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RUBEN ANTONIO VASQUEZ LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SANDRO  ALVAYAI  AHUMADA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 19:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 19:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 20:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIA EMELINA TITO GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN PATRICIO VEAS CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS BERNARDO BORQUEZ QUEZADA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 19:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 19:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 20:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS BARCINA CHELMES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ARSENIO LEONIDAS OPAZO ERICES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 19:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 20:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 20:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 21:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERMAN MANUEL VERGARA OLIVARES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUISELA ANDREA ROSALES ROSALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON ANTONIO VERGARA ZULUAGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ARTEMIO DEL FLORES HONORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS TEJADA RODRIGUEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN GUILLERMO FERNANDEZ EADE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN PATRICIO DIAZ CERDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON MARCOS TAPIA MIRANDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 06:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON MARCOS TAPIA MIRANDA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON MARCOS TAPIA MIRANDA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON MARCOS TAPIA MIRANDA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON MARCOS TAPIA MIRANDA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON MARCOS TAPIA MIRANDA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON MARCOS TAPIA MIRANDA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON MARCOS TAPIA MIRANDA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON MARCOS TAPIA MIRANDA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON MARCOS TAPIA MIRANDA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON MARCOS TAPIA MIRANDA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON MARCOS TAPIA MIRANDA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON MARCOS TAPIA MIRANDA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON MARCOS TAPIA MIRANDA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON MARCOS TAPIA MIRANDA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON MARCOS TAPIA MIRANDA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON MARCOS TAPIA MIRANDA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON MARCOS TAPIA MIRANDA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON MARCOS TAPIA MIRANDA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON MARCOS TAPIA MIRANDA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON MARCOS TAPIA MIRANDA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON MARCOS TAPIA MIRANDA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON MARCOS TAPIA MIRANDA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "IVONNE  CIFUENTES HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 19:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALFONSO LABARCA SANTANDER",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCOS ANTONIO PANIAGUA VILLALOBOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LAURA LETICIA PUENTE CHACÓN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "TANIA ISABEL VEAS VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 19:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL  ARAYA   PLAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 19:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO VARGAS AVILA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KARINA ODETTE SANTANDER ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO ALEJANDRO CHINGA ALFARO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN FELIPE ABURTO ABURTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN FELIPE ABURTO ABURTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN FELIPE ABURTO ABURTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN FELIPE ABURTO ABURTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SOLEDAD MILENA ECHALAR RAMIREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANIBAL ANTONIO LUNA RAMIREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO ANDRES TOROCO ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN ALEJANDRO ROJAS VALDES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 19:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 20:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 20:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 21:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 21:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 22:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 22:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALEXANDER SILVA RUIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEXANDER SILVA RUIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEXANDER SILVA RUIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEXANDER SILVA RUIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEXANDER SILVA RUIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEXANDER SILVA RUIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEXANDER SILVA RUIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEXANDER SILVA RUIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEXANDER SILVA RUIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALEXANDER SILVA RUIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEXANDER SILVA RUIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEXANDER SILVA RUIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEXANDER SILVA RUIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEXANDER SILVA RUIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEXANDER SILVA RUIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEXANDER SILVA RUIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEXANDER SILVA RUIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEXANDER SILVA RUIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEXANDER SILVA RUIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEXANDER SILVA RUIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEXANDER SILVA RUIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEXANDER SILVA RUIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEXANDER SILVA RUIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEXANDER SILVA RUIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEXANDER SILVA RUIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "DAYVI PATRICIO LEDEZMA TAPIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MATÍAS ANDRÉS CORTES BRIONES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO SOBARZO PARRA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO GERMAN VILLCA SALINAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "KEVIN ANDRES MEDRANO LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLÁS ANDRÉS BALTAZAR MILLA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARÍA ESTHER RIOS LOVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 19:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO  CUELLAR MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE ANTONIO JESUS GONZALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO VALENCIA FORERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 07:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX HURTADO FARELL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 19:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO LUIS VICENTE ATUNGA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 09:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 10:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 10:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 11:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 11:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 12:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 12:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 13:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 13:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 14:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 14:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 15:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 15:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 16:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 16:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 17:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 17:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 18:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR JIMENEZ VILLCA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-31 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-31 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-31 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-31 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-31 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-31 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-31 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-31 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-31 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-31 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-31 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-31 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-31 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-31 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-31 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-31 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-31 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-31 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-31 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-31 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-31 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: nan,
    lng: nan,
    tiempo: "2025-03-31 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE SUAREZ FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HAROLD WASHINTONG ARROYO ARROYO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN MURIEL RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ESTEBAN SEBASTIAN MAMANI .",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ZENÓN FREDDY TORREZ AZURDUY",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO HERMO QUISPE JIMENEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRUNO ALPIRE MEDEIROS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ELIAS  CAMPOS TACEO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 06:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO NUÑEZ ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "YOSLEIVIS  DARIAS ROJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-03-31 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO MENA MONASTERIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GABRIEL RICARDO CASTRO ARISTÍA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON ALBERTO VERGARA VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON ALBERTO VERGARA VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON ALBERTO VERGARA VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON ALBERTO VERGARA VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON ALBERTO VERGARA VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALBERTO VERGARA VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALBERTO VERGARA VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALBERTO VERGARA VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALBERTO VERGARA VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALBERTO VERGARA VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALBERTO VERGARA VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALBERTO VERGARA VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALBERTO VERGARA VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALBERTO VERGARA VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALBERTO VERGARA VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALBERTO VERGARA VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALBERTO VERGARA VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALBERTO VERGARA VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALBERTO VERGARA VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALBERTO VERGARA VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALBERTO VERGARA VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALBERTO VERGARA VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON ALBERTO VERGARA VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON ALBERTO VERGARA VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON ALBERTO VERGARA VEAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO AGUSTÍN OLIVARES MONTECINOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CESAR  ALBANEZ PEÑA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO SARRIA ACOSTA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-03-31 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-03-31 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312278252586,
    lng: -68.895754118624,
    tiempo: "2025-03-31 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-03-31 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO ALVARO VARAS CACERES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO HERNAN AVALOS AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "DANIEL ISAAC PEZOA ALVAREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ALEJANDRO MADARIAGA MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-03-31 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  }
];