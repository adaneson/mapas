window.personas = [
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR CHOQUE COPA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO DEL CARMEN BRUNA GARCIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO ANTONIO NAVEA ALCAYAGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 06:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME PATRICIO CREMER VERGARA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 06:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EMILIO FERNANDO DONOSO HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS SADY ESCOBAR FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ARMANDO LOPEZ VARAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROBERTO ANTONIO COLLAO JIL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN LEOPOLDO PEREZ OSSANDON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 19:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 19:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 20:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 20:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 21:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 21:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER EFRAÍN MONTEJO CUTURRUFO",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MANUEL GATICA AZOCAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 19:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 19:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 20:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LEOPOLDO YAMIL ALUCEMA VEGA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 20:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN MAURICIO ALVARADO ARAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ERNESTO ALEXIS FUENTES AGUILAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VLADIMIR TORREZ QUISPE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ANTONIO ESQUIVEL BASAURE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ANGEL FAUNDEZ JIMENEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 19:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 19:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 20:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSÓN PATRICIO VIDAURRE NAVEAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 20:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MOISES ANDRES SANTANA CORTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANILO ALONSO PINTO MENDOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR ALBERTO HEREDIA BARRIGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID DANIEL GUAJARDO MORALES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR ANDRES INOSTROZA HERNANDEZ",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ANTONIO PALACIOS CASTILLO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ARTURO GABRIEL GONZALEZ ZAPATA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "ARTURO GABRIEL GONZALEZ ZAPATA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO GABRIEL GONZALEZ ZAPATA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO GABRIEL GONZALEZ ZAPATA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO GABRIEL GONZALEZ ZAPATA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO GABRIEL GONZALEZ ZAPATA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO GABRIEL GONZALEZ ZAPATA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO GABRIEL GONZALEZ ZAPATA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO GABRIEL GONZALEZ ZAPATA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO GABRIEL GONZALEZ ZAPATA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO GABRIEL GONZALEZ ZAPATA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO GABRIEL GONZALEZ ZAPATA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO GABRIEL GONZALEZ ZAPATA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO GABRIEL GONZALEZ ZAPATA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO GABRIEL GONZALEZ ZAPATA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO GABRIEL GONZALEZ ZAPATA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO GABRIEL GONZALEZ ZAPATA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO GABRIEL GONZALEZ ZAPATA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO GABRIEL GONZALEZ ZAPATA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO GABRIEL GONZALEZ ZAPATA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO GABRIEL GONZALEZ ZAPATA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO GABRIEL GONZALEZ ZAPATA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO GABRIEL GONZALEZ ZAPATA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO GABRIEL GONZALEZ ZAPATA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SEBASTIAN ANDRES ORMEÑO MOENA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO ANTONIO MEJIAS MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DAVID CARVAJAL ARAYA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 06:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 19:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 19:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 20:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "DIANA YAJAHIRA RIVERA AGUILERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 20:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMON  AGUILERA CEJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO ANDRES LAZO LAZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAVIER ANDRES DIAZ DIAZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAXIMO ALEJANDRO TRONCOSO MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO ALEXANDER JARA YEPSEN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONNATHAN MARCELO ROMO TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON FABIAN WHITE NEGRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL ANDRES MUÑOZ VEGA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO ABRAHAM MANCILLA DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ANTHONNY CORNEJO SANDOVAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL ALEJANDRO VALDES ZEPEDA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MICHAEL AYAVIRE TERAN",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CAMILO IGNACIO MEDRANO CORTES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WLADIMIR DE JESUS IGLESIAS REYES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD ANTONIO FUENTES FUENTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ESTEBAN HERNAN PEREIRA MUÑOZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ANDRES FIGUEROA PEÑA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ANDRES FIGUEROA PEÑA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ANDRES FIGUEROA PEÑA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ANDRES FIGUEROA PEÑA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ANDRES FIGUEROA PEÑA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ANDRES FIGUEROA PEÑA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ANDRES FIGUEROA PEÑA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ANDRES FIGUEROA PEÑA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ANDRES FIGUEROA PEÑA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ANDRES FIGUEROA PEÑA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ANDRES FIGUEROA PEÑA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ANDRES FIGUEROA PEÑA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ANDRES FIGUEROA PEÑA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ANDRES FIGUEROA PEÑA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ANDRES FIGUEROA PEÑA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ANDRES FIGUEROA PEÑA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ANDRES FIGUEROA PEÑA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ANDRES FIGUEROA PEÑA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ANDRES FIGUEROA PEÑA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ANDRES FIGUEROA PEÑA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ANDRES FIGUEROA PEÑA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ANDRES FIGUEROA PEÑA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ANDRES FIGUEROA PEÑA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ANDRES FIGUEROA PEÑA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON WILLIAMS CERDA PANIAGUA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO PULGAR RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCO FELIPE NETTLE FUENTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS VALENZUELA REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN RAMON RIGOBERTO REBOLLEDO TRONCOSO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO IGNACIO TAPIA ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO MORALES CASTILLO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ELISEO  AQUINO AUCACHI",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILZAR CARLOS CONDORI MAMANI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSO LUCIANO ROSAS ALCALA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS OSCAR VIDAURRE MAMANI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEMER RUELAS CARTAGENA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR MACHICADO HUANCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR MACHICADO HUANCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR MACHICADO HUANCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR MACHICADO HUANCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR MACHICADO HUANCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR MACHICADO HUANCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR MACHICADO HUANCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR MACHICADO HUANCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR MACHICADO HUANCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR MACHICADO HUANCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR MACHICADO HUANCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR MACHICADO HUANCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR MACHICADO HUANCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR MACHICADO HUANCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR MACHICADO HUANCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR MACHICADO HUANCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR MACHICADO HUANCA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 14:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR MACHICADO HUANCA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 15:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR MACHICADO HUANCA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR MACHICADO HUANCA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR MACHICADO HUANCA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR MACHICADO HUANCA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR MACHICADO HUANCA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR MACHICADO HUANCA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR MACHICADO HUANCA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR MACHICADO HUANCA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GINO VACA CANDIA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS HUAMAN YATACO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARTURO BRAULIO QUISPE VILLCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR DANIEL CALLE CIENFUEGOS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DONATO COLQUE COCHOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICKY ARNOLD CABRERA AVEDAÑO",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMIRO QUISPE APAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS FERNANDO TEJERINA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-10 08:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 11:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 14:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 14:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 15:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 15:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DANNY PAREDES TAPIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS QUISPE LOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL  MEDRANO  MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO ARMANDO ARZE ENDARA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 06:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUSTAVO ADOLFO CALDERON CAMBEROS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX CUCHALLO MORALES",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ADEMAR ALBARO SALAZAR PRADO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAURCIO ARTEAGA FLORES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAMON GONGORA TIRINA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAINOR CARTAGENA GUARI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 18:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO GUIDO AGUILAR CHOQUE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 18:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MERY DURAN ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RUBEN MENACHO MONTERO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 06:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-10 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHON JAIRO MONTAÑO VARONA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE ABRAHAM COLQUE SOLIZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIO EUGENIO ESCALERA MIRANDA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROGER CARLOS BALTAZAR RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DELFIN FLORES PANIAGUA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 06:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-10 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGAPITO MAMANI HUARACHI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ASTULLA RODRIGUEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-10 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FAUSTINO RENTERIA DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RONALD MICHAEL HIDALGO TITO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311243775405,
    lng: -68.892535271906,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "KEVIN ALEXANDER RICO CASTRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-10 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-10 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-10 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-10 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-10 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-10 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-10 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-10 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO EDMUNDO TAPIA VALDIVIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-10 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  }
];