window.personas = [
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO SAAVEDRA ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALONSO DEL CARMEN MANQUEZ NUÑEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 07:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 18:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 07:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RENE PATRICIO CAMPOS BADILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 07:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR OSINAGA ANDRADE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEXIS AHUMADA PIZARRO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR MARCELO ARAYA GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR MARCELO ARAYA GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR MARCELO ARAYA GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR MARCELO ARAYA GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR MARCELO ARAYA GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR MARCELO ARAYA GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR MARCELO ARAYA GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR MARCELO ARAYA GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR MARCELO ARAYA GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR MARCELO ARAYA GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR MARCELO ARAYA GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR MARCELO ARAYA GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR MARCELO ARAYA GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR MARCELO ARAYA GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR MARCELO ARAYA GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR MARCELO ARAYA GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR MARCELO ARAYA GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR MARCELO ARAYA GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR MARCELO ARAYA GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR MARCELO ARAYA GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR MARCELO ARAYA GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR MARCELO ARAYA GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR MARCELO ARAYA GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR MARCELO ARAYA GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR MARCELO ARAYA GONZALEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID ALEJANDRO OLIVARES NUÑEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "SERGIO STANISLAO NEGRETE PEREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO STANISLAO NEGRETE PEREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO STANISLAO NEGRETE PEREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO STANISLAO NEGRETE PEREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO STANISLAO NEGRETE PEREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO STANISLAO NEGRETE PEREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO STANISLAO NEGRETE PEREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO STANISLAO NEGRETE PEREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO STANISLAO NEGRETE PEREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO STANISLAO NEGRETE PEREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO STANISLAO NEGRETE PEREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO STANISLAO NEGRETE PEREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO STANISLAO NEGRETE PEREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO STANISLAO NEGRETE PEREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO STANISLAO NEGRETE PEREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO STANISLAO NEGRETE PEREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO STANISLAO NEGRETE PEREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO STANISLAO NEGRETE PEREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO STANISLAO NEGRETE PEREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO STANISLAO NEGRETE PEREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO STANISLAO NEGRETE PEREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO STANISLAO NEGRETE PEREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SERGIO STANISLAO NEGRETE PEREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CHRISTIAN ENRIQUE GONZALEZ SAAVEDRA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE MIGUEL SOTO FIGUEROA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 06:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO ALEJANDRO JAIME RIVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 06:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO ALEJANDRO TAPIA CARVAJAL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GILBERTO DEL TRANSITO OGALDE ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOHN MAYKLEN LOPEZ CARRILLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOHN MAYKLEN LOPEZ CARRILLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHN MAYKLEN LOPEZ CARRILLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHN MAYKLEN LOPEZ CARRILLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHN MAYKLEN LOPEZ CARRILLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHN MAYKLEN LOPEZ CARRILLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHN MAYKLEN LOPEZ CARRILLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHN MAYKLEN LOPEZ CARRILLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHN MAYKLEN LOPEZ CARRILLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHN MAYKLEN LOPEZ CARRILLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHN MAYKLEN LOPEZ CARRILLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHN MAYKLEN LOPEZ CARRILLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHN MAYKLEN LOPEZ CARRILLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHN MAYKLEN LOPEZ CARRILLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHN MAYKLEN LOPEZ CARRILLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHN MAYKLEN LOPEZ CARRILLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHN MAYKLEN LOPEZ CARRILLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHN MAYKLEN LOPEZ CARRILLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHN MAYKLEN LOPEZ CARRILLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHN MAYKLEN LOPEZ CARRILLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHN MAYKLEN LOPEZ CARRILLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHN MAYKLEN LOPEZ CARRILLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHN MAYKLEN LOPEZ CARRILLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDUARDO ESTEBAN DIAZ TAPIA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 07:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 06:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-18 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS EDUARDO ARAYA ZAMARCA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.312849261481,
    lng: -68.888485284643,
    tiempo: "2025-05-18 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-18 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 19:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GEORGE EDWARD MARQUEZ CAMPOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BRYAN ALEXIS NAVARRO CHACANA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 06:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN FELIPE CATALDO NAVARRETE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GIANT NYDENKO JULIO JOFRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 06:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "GIANT NYDENKO JULIO JOFRE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "GIANT NYDENKO JULIO JOFRE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "GIANT NYDENKO JULIO JOFRE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "GIANT NYDENKO JULIO JOFRE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "GIANT NYDENKO JULIO JOFRE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "GIANT NYDENKO JULIO JOFRE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "GIANT NYDENKO JULIO JOFRE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "GIANT NYDENKO JULIO JOFRE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "GIANT NYDENKO JULIO JOFRE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "GIANT NYDENKO JULIO JOFRE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "GIANT NYDENKO JULIO JOFRE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "GIANT NYDENKO JULIO JOFRE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "GIANT NYDENKO JULIO JOFRE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "GIANT NYDENKO JULIO JOFRE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "GIANT NYDENKO JULIO JOFRE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "GIANT NYDENKO JULIO JOFRE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "GIANT NYDENKO JULIO JOFRE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "GIANT NYDENKO JULIO JOFRE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "GIANT NYDENKO JULIO JOFRE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "GIANT NYDENKO JULIO JOFRE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "GIANT NYDENKO JULIO JOFRE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "GIANT NYDENKO JULIO JOFRE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "GIANT NYDENKO JULIO JOFRE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "GIANT NYDENKO JULIO JOFRE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "GIANT NYDENKO JULIO JOFRE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JANET SILVA CRUZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "HUGO ENRIQUE LUZA CHACANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO ENRIQUE AYABIRE MIRANDA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO DANIEL ESPINOZA PIZARRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO DANIEL ESPINOZA PIZARRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO DANIEL ESPINOZA PIZARRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO DANIEL ESPINOZA PIZARRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO DANIEL ESPINOZA PIZARRO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO DANIEL ESPINOZA PIZARRO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO DANIEL ESPINOZA PIZARRO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO DANIEL ESPINOZA PIZARRO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO DANIEL ESPINOZA PIZARRO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO DANIEL ESPINOZA PIZARRO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO DANIEL ESPINOZA PIZARRO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO DANIEL ESPINOZA PIZARRO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO DANIEL ESPINOZA PIZARRO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO DANIEL ESPINOZA PIZARRO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO DANIEL ESPINOZA PIZARRO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO DANIEL ESPINOZA PIZARRO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO DANIEL ESPINOZA PIZARRO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO DANIEL ESPINOZA PIZARRO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO DANIEL ESPINOZA PIZARRO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO DANIEL ESPINOZA PIZARRO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO DANIEL ESPINOZA PIZARRO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO DANIEL ESPINOZA PIZARRO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO DANIEL ESPINOZA PIZARRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO DANIEL ESPINOZA PIZARRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 06:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "NICOLAS LEONARDO PEREZ ALLENDE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 06:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "ELISEO HUAMAN CAMPOS",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE EMERSON YACTAYO  GUTIERREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GABRIEL VELASCO AYOVI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 06:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-18 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "WALDO CASTRO APAZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAIKO ASATO HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO HUAYTA COTJIRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EFRAIN MAMANI BARRIENTOS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARTIN SARZURI QUISPE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TITO VASQUEZ CASANA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AGUSTIN ZAMBRANA BERVO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AGUSTIN ZAMBRANA BERVO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGUSTIN ZAMBRANA BERVO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AGUSTIN ZAMBRANA BERVO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AGUSTIN ZAMBRANA BERVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AGUSTIN ZAMBRANA BERVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGUSTIN ZAMBRANA BERVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGUSTIN ZAMBRANA BERVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGUSTIN ZAMBRANA BERVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGUSTIN ZAMBRANA BERVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGUSTIN ZAMBRANA BERVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGUSTIN ZAMBRANA BERVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGUSTIN ZAMBRANA BERVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGUSTIN ZAMBRANA BERVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AGUSTIN ZAMBRANA BERVO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AGUSTIN ZAMBRANA BERVO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGUSTIN ZAMBRANA BERVO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGUSTIN ZAMBRANA BERVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "AGUSTIN ZAMBRANA BERVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGUSTIN ZAMBRANA BERVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGUSTIN ZAMBRANA BERVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGUSTIN ZAMBRANA BERVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGUSTIN ZAMBRANA BERVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGUSTIN ZAMBRANA BERVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "AGUSTIN ZAMBRANA BERVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL MOISES PAILLAN  EPUL",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RADOMIRO ZEPEDA PASTRANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-18 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-18 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-18 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  }
];