window.personas = [
  {
    nombre: "ALDO AURELIO ESCOBAR CORTES",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "ALDO AURELIO ESCOBAR CORTES",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "ALDO AURELIO ESCOBAR CORTES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-30 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "ALDO AURELIO ESCOBAR CORTES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-30 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALDO AURELIO ESCOBAR CORTES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-30 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALDO AURELIO ESCOBAR CORTES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-30 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALDO AURELIO ESCOBAR CORTES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-30 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALDO AURELIO ESCOBAR CORTES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-30 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALDO AURELIO ESCOBAR CORTES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-30 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALDO AURELIO ESCOBAR CORTES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-30 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALDO AURELIO ESCOBAR CORTES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-30 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALDO AURELIO ESCOBAR CORTES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-30 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALDO AURELIO ESCOBAR CORTES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-30 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALDO AURELIO ESCOBAR CORTES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-30 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALDO AURELIO ESCOBAR CORTES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-30 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ALDO AURELIO ESCOBAR CORTES",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-30 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR HERNANDEZ BARRERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JAIME FERNANDEZ MICHEA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RICHARD EDUARDO VARGAS VERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RICHARD EDUARDO VARGAS VERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RICHARD EDUARDO VARGAS VERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICHARD EDUARDO VARGAS VERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICHARD EDUARDO VARGAS VERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICHARD EDUARDO VARGAS VERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICHARD EDUARDO VARGAS VERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICHARD EDUARDO VARGAS VERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICHARD EDUARDO VARGAS VERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICHARD EDUARDO VARGAS VERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICHARD EDUARDO VARGAS VERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICHARD EDUARDO VARGAS VERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICHARD EDUARDO VARGAS VERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICHARD EDUARDO VARGAS VERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICHARD EDUARDO VARGAS VERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICHARD EDUARDO VARGAS VERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICHARD EDUARDO VARGAS VERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICHARD EDUARDO VARGAS VERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICHARD EDUARDO VARGAS VERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICHARD EDUARDO VARGAS VERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICHARD EDUARDO VARGAS VERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICHARD EDUARDO VARGAS VERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RICHARD EDUARDO VARGAS VERA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICHARD EDUARDO VARGAS VERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RICHARD EDUARDO VARGAS VERA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON DAVID FERNANDEZ CASTRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN VALDEBENITO TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO CORTEZ MONDACA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 07:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "CESAR CORTES BARRAZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL AGUSTÍN PONCE MANCILLA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO IBAR BARRERA ARAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON GERARDO TAPIA CARVAJAL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS MANUEL MORALES ALVAREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL ALBERTO VEGA ORTIZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PEDRO HAROLDO GUERRERO PIZARRO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE JULIAN COROSEO ORTIZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PABLO TRIGO TRIGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SEGISMUNDO BAEZA PAEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JORGE LAUTARO FUENTES CRUZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 07:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILLIAM VELASQUEZ SANTIBAÑEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIO FRANCISCO GUERRERO HERNANDEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALFREDO ESPERGUEL OÑATE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS ALBERTO MONTOYA REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 20:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 20:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VIRGINIA AURORA GODOY ARANCIBIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 21:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DANIEL RODRIGO PIZARRO AGUILERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID RIVERA RIVERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "RICARDO GUILLERMO MENDIZABAL PINTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 20:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 20:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALEJANDRO ALFREDO MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 21:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN ENRIQUE CERVANTES CERVANTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN ENRIQUE CERVANTES CERVANTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ENRIQUE CERVANTES CERVANTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ENRIQUE CERVANTES CERVANTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ENRIQUE CERVANTES CERVANTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ENRIQUE CERVANTES CERVANTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ENRIQUE CERVANTES CERVANTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ENRIQUE CERVANTES CERVANTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ENRIQUE CERVANTES CERVANTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ENRIQUE CERVANTES CERVANTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ENRIQUE CERVANTES CERVANTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ENRIQUE CERVANTES CERVANTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ENRIQUE CERVANTES CERVANTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ENRIQUE CERVANTES CERVANTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ENRIQUE CERVANTES CERVANTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ENRIQUE CERVANTES CERVANTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ENRIQUE CERVANTES CERVANTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ENRIQUE CERVANTES CERVANTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ENRIQUE CERVANTES CERVANTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ENRIQUE CERVANTES CERVANTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ENRIQUE CERVANTES CERVANTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ENRIQUE CERVANTES CERVANTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ENRIQUE CERVANTES CERVANTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ENRIQUE CERVANTES CERVANTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL BERNARDO ALFARO MIRANDA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO INAREJO TOLEDO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO INAREJO TOLEDO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO INAREJO TOLEDO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO INAREJO TOLEDO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO INAREJO TOLEDO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO INAREJO TOLEDO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO INAREJO TOLEDO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO INAREJO TOLEDO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO INAREJO TOLEDO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO INAREJO TOLEDO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO INAREJO TOLEDO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO INAREJO TOLEDO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO INAREJO TOLEDO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO INAREJO TOLEDO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO INAREJO TOLEDO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO INAREJO TOLEDO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO INAREJO TOLEDO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO INAREJO TOLEDO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO INAREJO TOLEDO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO INAREJO TOLEDO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO INAREJO TOLEDO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO INAREJO TOLEDO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO INAREJO TOLEDO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO INAREJO TOLEDO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "MAURICIO ALEJANDRO INAREJO TOLEDO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FREDY RICARDO RAMOS SEGUEL",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS CORTES PASTEN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 06:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS CORTES PASTEN",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS CORTES PASTEN",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CORTES PASTEN",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CORTES PASTEN",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CORTES PASTEN",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CORTES PASTEN",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CORTES PASTEN",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CORTES PASTEN",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CORTES PASTEN",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CORTES PASTEN",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CORTES PASTEN",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CORTES PASTEN",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CORTES PASTEN",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CORTES PASTEN",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CORTES PASTEN",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CORTES PASTEN",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CORTES PASTEN",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CORTES PASTEN",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CORTES PASTEN",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CORTES PASTEN",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CORTES PASTEN",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CORTES PASTEN",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS CORTES PASTEN",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS CORTES PASTEN",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS CORTES PASTEN",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALBERTO BELEN RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROSA LUCI NINA ALI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO OLAZO FRANCO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NATANIEL PEDRO JERALDO GALARCE",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIOT JOHAN CASTILLO ARAYA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "YERKA ELENA MORALES ARNES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 06:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "YERKA ELENA MORALES ARNES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "YERKA ELENA MORALES ARNES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YERKA ELENA MORALES ARNES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YERKA ELENA MORALES ARNES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YERKA ELENA MORALES ARNES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YERKA ELENA MORALES ARNES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YERKA ELENA MORALES ARNES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YERKA ELENA MORALES ARNES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YERKA ELENA MORALES ARNES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YERKA ELENA MORALES ARNES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YERKA ELENA MORALES ARNES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YERKA ELENA MORALES ARNES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YERKA ELENA MORALES ARNES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YERKA ELENA MORALES ARNES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YERKA ELENA MORALES ARNES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YERKA ELENA MORALES ARNES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YERKA ELENA MORALES ARNES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YERKA ELENA MORALES ARNES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YERKA ELENA MORALES ARNES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YERKA ELENA MORALES ARNES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YERKA ELENA MORALES ARNES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YERKA ELENA MORALES ARNES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YERKA ELENA MORALES ARNES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YERKA ELENA MORALES ARNES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "YERKA ELENA MORALES ARNES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 20:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 20:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS ENRIQUE MONTECINOS VALLEJOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 21:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "HECTOR ALEJANDRO HERRERA CALDERON",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIA ANDREA CORTES CORTES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PATRICIO MANUEL SEPULVEDA TORRES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RICARDO ANTONIO GONZALEZ PEÑALOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OSCAR DANIEL MARIN COLLAO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "URSULA ANDREE RODRIGUEZ SAAVEDRA",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EMILIO JOSE POZO BARRAZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "EMILIO JOSE POZO BARRAZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "EMILIO JOSE POZO BARRAZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "EMILIO JOSE POZO BARRAZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "EMILIO JOSE POZO BARRAZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "EMILIO JOSE POZO BARRAZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "EMILIO JOSE POZO BARRAZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "EMILIO JOSE POZO BARRAZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "EMILIO JOSE POZO BARRAZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "EMILIO JOSE POZO BARRAZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "EMILIO JOSE POZO BARRAZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "EMILIO JOSE POZO BARRAZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "EMILIO JOSE POZO BARRAZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "EMILIO JOSE POZO BARRAZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "EMILIO JOSE POZO BARRAZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "EMILIO JOSE POZO BARRAZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "EMILIO JOSE POZO BARRAZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "EMILIO JOSE POZO BARRAZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "EMILIO JOSE POZO BARRAZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "EMILIO JOSE POZO BARRAZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "EMILIO JOSE POZO BARRAZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "EMILIO JOSE POZO BARRAZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "EMILIO JOSE POZO BARRAZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "EMILIO JOSE POZO BARRAZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CLAUDIO RODOLFO SALAS ROA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO RODOLFO SALAS ROA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO RODOLFO SALAS ROA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO RODOLFO SALAS ROA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO RODOLFO SALAS ROA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO RODOLFO SALAS ROA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO RODOLFO SALAS ROA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO RODOLFO SALAS ROA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO RODOLFO SALAS ROA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO RODOLFO SALAS ROA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO RODOLFO SALAS ROA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO RODOLFO SALAS ROA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO RODOLFO SALAS ROA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO RODOLFO SALAS ROA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO RODOLFO SALAS ROA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO RODOLFO SALAS ROA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO RODOLFO SALAS ROA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO RODOLFO SALAS ROA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO RODOLFO SALAS ROA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO RODOLFO SALAS ROA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO RODOLFO SALAS ROA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO RODOLFO SALAS ROA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CLAUDIO RODOLFO SALAS ROA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 06:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 08:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL  CASTILLO  MUÑOZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FABRIZIO DAVID ROJAS SOLAR",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 20:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 20:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SCARLETT CELESTE MOSCOSO SILVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 21:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN GERMAN CORIA MEDRANO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAB NEHEMIAS CAMACHO LLAVES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERALD EDUARDO GALLEGUILLOS HIDALGO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JONATHAN ORDENES LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.313387710135,
    lng: -68.889005564052,
    tiempo: "2025-05-30 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANGELO JAVIER HIDALGO HIDALGO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "OMAR ALEJANDRO HIDALGO MARAMBIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OMAR ALEJANDRO HIDALGO MARAMBIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OMAR ALEJANDRO HIDALGO MARAMBIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OMAR ALEJANDRO HIDALGO MARAMBIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OMAR ALEJANDRO HIDALGO MARAMBIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OMAR ALEJANDRO HIDALGO MARAMBIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OMAR ALEJANDRO HIDALGO MARAMBIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OMAR ALEJANDRO HIDALGO MARAMBIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OMAR ALEJANDRO HIDALGO MARAMBIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OMAR ALEJANDRO HIDALGO MARAMBIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OMAR ALEJANDRO HIDALGO MARAMBIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OMAR ALEJANDRO HIDALGO MARAMBIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OMAR ALEJANDRO HIDALGO MARAMBIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OMAR ALEJANDRO HIDALGO MARAMBIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OMAR ALEJANDRO HIDALGO MARAMBIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OMAR ALEJANDRO HIDALGO MARAMBIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OMAR ALEJANDRO HIDALGO MARAMBIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OMAR ALEJANDRO HIDALGO MARAMBIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OMAR ALEJANDRO HIDALGO MARAMBIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OMAR ALEJANDRO HIDALGO MARAMBIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OMAR ALEJANDRO HIDALGO MARAMBIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OMAR ALEJANDRO HIDALGO MARAMBIO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "OMAR ALEJANDRO HIDALGO MARAMBIO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR DAMIAN YAÑEZ CUBILLOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 06:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO JOSE ORDENES GAHONA",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RODRIGO ALEXIS HERRERA HERRERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUILLERMO DAVID BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-30 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-30 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.31583157133,
    lng: -68.889757363114,
    tiempo: "2025-05-30 17:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCISCO MELQUIADES CHAVEZ ORELLANA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANTONIO ADRIAN RAMOS HONORES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN ALEJANDRO ROSAS CLARO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPE BARRERA FRES",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDGAR ALEXANDRO ARANCIBIA SANDON",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:00:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 12:30:00",
    empresa: "NEXXO",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTIAN  GONZÁLEZ SOTO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BENJAMIN HUMBERTO ALCOZER ESPINOZA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 19:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "BASTIAN PATRICIO HERNANDEZ MALDONADO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MALCON ATREYU ESQUIVEL ALVAREZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL JESUS ALVAREZ CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "ARIEL JESUS ALVAREZ CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL JESUS ALVAREZ CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL JESUS ALVAREZ CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL JESUS ALVAREZ CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL JESUS ALVAREZ CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL JESUS ALVAREZ CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL JESUS ALVAREZ CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL JESUS ALVAREZ CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL JESUS ALVAREZ CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL JESUS ALVAREZ CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL JESUS ALVAREZ CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL JESUS ALVAREZ CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL JESUS ALVAREZ CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL JESUS ALVAREZ CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL JESUS ALVAREZ CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL JESUS ALVAREZ CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL JESUS ALVAREZ CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL JESUS ALVAREZ CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL JESUS ALVAREZ CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL JESUS ALVAREZ CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL JESUS ALVAREZ CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL JESUS ALVAREZ CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ARIEL JESUS ALVAREZ CORTES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GERARDO VALENTE FLORES CENTENO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "CRISTOFER ROJAS CORTES",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "GASPAR JESUS VIDAL ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GASPAR JESUS VIDAL ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GASPAR JESUS VIDAL ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GASPAR JESUS VIDAL ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GASPAR JESUS VIDAL ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GASPAR JESUS VIDAL ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GASPAR JESUS VIDAL ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GASPAR JESUS VIDAL ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GASPAR JESUS VIDAL ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GASPAR JESUS VIDAL ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GASPAR JESUS VIDAL ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GASPAR JESUS VIDAL ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GASPAR JESUS VIDAL ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GASPAR JESUS VIDAL ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GASPAR JESUS VIDAL ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GASPAR JESUS VIDAL ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GASPAR JESUS VIDAL ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GASPAR JESUS VIDAL ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GASPAR JESUS VIDAL ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GASPAR JESUS VIDAL ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GASPAR JESUS VIDAL ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GASPAR JESUS VIDAL ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GASPAR JESUS VIDAL ALVAREZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FELIPHE IGNACIO BAUTISTA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "FRANCO BENJAMIN FUENTES AVENDAÑO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON HERNÁN SUÁREZ CORTÉS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDY ANTONY GODOY CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOHAO BENJAMIN GABELO DIAZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEREMY BRYAN OCHOA GUAMAN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HERNAN MACHACA MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 06:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ALISSON SUSANA VARGAS RODRIGUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS CONDORI MAMANI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE ALBERTO COELLO ACOSTA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "ALEX MENDOZA CHOQUETICLLA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 18:30:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARIO FERNANDO GOMEZ CLAVIJO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 19:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFERSON MARTINEZ RIASCO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:30:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ATILIO  IBARRA LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:00:00",
    empresa: "NEXXO",
    modo: "UBICADO"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANACLETO CACERES SALVADOR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELEOTERIO ZAPATA DELGADILLO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MARCELO MOSCOSO CUELLAR",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAIAS RODRIGO SAAVEDRA CLEMENTE",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "GUMERCINDO PEDRAZA MENDOZA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS PERALES JOAQUIN",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ELIAS DAVID MENDEZ MARTINEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ANDRES FELIPE SANTAMARIA MOLINA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DIEGO FLORES CORDOVA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "TOVIAS FELIX ROJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS GUERRA REJAS",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN CARLOS RAMIREZ CORINO",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ISAID AÑEZ ZEBALLOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "SIMON POTICA CALLEJAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 07:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 07:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 08:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 08:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 09:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 09:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 10:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 10:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 11:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 11:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 12:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 12:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 13:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 13:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 14:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 14:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 15:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 15:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 16:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 16:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 17:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 17:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 18:00:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 18:30:00",
    empresa: "BERLIAM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "VICTOR FLORES TALAVERA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 19:00:00",
    empresa: "BERLIAM",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MIGUEL CUELLAR REYES",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 07:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.316950795456,
    lng: -68.890293484522,
    tiempo: "2025-05-30 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "RAUL ARISPE SANCHEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 19:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "WILFREDO CAYO ARENAS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "NELSON PEREDO PIZO",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "CARLOS DANIEL IGNACIO AIREYU",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEFFERSON DAVID ALVEAR GAMBOA",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 19:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "FERNANDO ABARIOJO ONARRI",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 07:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 08:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 08:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 09:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 09:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 10:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 10:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 11:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 11:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 12:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 12:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 13:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 13:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 14:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 14:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 15:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 15:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 16:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 16:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 17:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 17:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 18:00:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSE LUIS HURTADO FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 18:30:00",
    empresa: "PACOLL ING. Y CÍA. LTDA",
    modo: "UBICADO"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDYSON RAMOS CALIZAYA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROLANDO RAMOS FERNANDEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "EDWIN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DOUGLAS SALVATIERRA NEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "YONATAN MARINO GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.311201658921,
    lng: -68.896504171231,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "DAVID MOISES GUTIERREZ BRAVO",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "PETRIENNE MENACHO REVOLLO",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "ROMER MENDOLAS MAMANI",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JHONNY GARCIA COLQUE",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MILTON GALLOSO MOSQUEIRA",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JEAN PAUL LIMARINO LOPEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOAQUIN QUISPE MEJIA",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 06:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 07:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 08:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 08:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 09:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 09:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 10:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 10:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 11:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 11:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 12:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 12:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 13:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 13:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 14:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 14:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 15:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 15:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 16:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 16:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 17:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 17:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 18:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 18:30:00",
    empresa: "SIGDO KOPPERS",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS ALBERTO BECERRA VARGAS",
    lat: -22.310478882107,
    lng: -68.916832718385,
    tiempo: "2025-05-30 19:00:00",
    empresa: "SIGDO KOPPERS",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN SARZURI AGUIRRE",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JOSUE GONZALES RAMOS",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "IVAN RIVADENEIRA HENRIQUEZ",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 06:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.311372019423,
    lng: -68.895016482911,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "HUMBERTO JAVIER BUSTAMANTE VASQUEZ",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "JUAN ANTONIO IRIBARREN DIAZ",
    lat: -22.353446659086,
    lng: -68.856164540738,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.312733751018,
    lng: -68.897586458245,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.311625584499,
    lng: -68.892951459097,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.328839025764,
    lng: -68.885274223686,
    tiempo: "2025-05-30 18:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "MANUEL VEGA CARVAJAL",
    lat: -22.35227688208,
    lng: -68.857303744188,
    tiempo: "2025-05-30 19:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 07:00:00",
    empresa: "KDM",
    modo: "UBICADO"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 07:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 08:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 08:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 09:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 09:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 10:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 10:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 11:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 11:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 12:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 12:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 13:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 13:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 14:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 14:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 15:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 15:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 16:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 16:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 17:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 17:30:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  },
  {
    nombre: "LUIS EDUARDO MARTINEZ CONTRERAS",
    lat: -22.315509638749,
    lng: -68.923715554613,
    tiempo: "2025-05-30 18:00:00",
    empresa: "KDM",
    modo: "NO UBICABLE"
  }
];